
// Export all flavor-related types and functions from a single entry point
export * from './types';
export * from './ingredients';
export * from './recommendations';
export * from './profileGenerator';
export * from './aiSuggestions';
